#!/usr/bin/python

#coding:utf-8

  import os

 x = int(raw_input("输入数字：")


#for i in range(10):
##     print i

#else:
#  print 'else'


for  i in range(100):
      
     if  i % 2 == 0:
#         continue
#    elif  i % 2 !== 0:
#
#         break     
      print i

