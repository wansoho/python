#!/usr/bin/python
#coding:utf-8
#a = 10
#b = 2
c = $a+$b
print(c)

score = 40

if score>=80:
    print("很好")
elif score>=60:
    print("及格")
elif score>=30:
    print("不及格")
else:
    print("很差")


