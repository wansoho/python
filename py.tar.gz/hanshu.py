#!/usr/bin/python
#coding:utf-8

def speak():
    print("are you ok")

def max(a,b):
    if a>b:
        return a
    else:
        return b



speak()
print(max(3,2))
