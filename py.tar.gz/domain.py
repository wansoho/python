#!/usr/bin/env python
#encoding:utf-8
#已交互式的方式实现查询域名的A记录

import dns.resolver
domain = raw_input("please input an domain: ")
A = dns.resolver.query(domain,'A')#指定查询为A记录
for i in A.response.answer:
     for j in i.items:
         print j.address
