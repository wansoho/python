#!/usr/bin/python

#coding:utf-8

num = raw_input()

print num

for i in range(num):
    if i % 2 == 0:
      print i
