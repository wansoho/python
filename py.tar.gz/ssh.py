#!/usr/bin/env python

import paramiko
import sys,os

host = '192.168.226.129'
user = 'wansoho'
password = '123456'

cmd = 'df'

s = paramiko.SSHClient()
s.load_system_host_keys()
s.set_missing_host_key_policy(paramiko.AutoAddPolicy())

s.connect(host,22,user,password,timeout=5)
stdin,stdout,stderr = s.exec_command(cmd)

cmd_result = stdout.read(),stderr.read()

for line in cmd_result:
    print line,

s.close()
