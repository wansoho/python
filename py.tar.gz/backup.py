#!/usr/bin/env python
#!encoding:utf-8
#mysqlbackup_v1是一个简单的面向过程编程的脚本
#大致流程 连接->备份->压缩->检查备份->邮件通知
import os
import time
import datetime

#import DATETIME as DATETIME

DB_HOST = '192.168.226.130'
DB_USER = 'wansoho'
DB_USER_PASSWORD = '123456'
DB_NAME = 'sxs'
BACKUP_PATCH = '/data/backup/'
DATETIME = time.strftime('%m%d%Y-%H%M%S')
TODAYBACKUPPATH = BACKUP_PATCH + DATETIME
#检查备份文件是否存在，不存在就创建他
print "creating backup folder"
if not os.path.exists(TODAYBACKUPPATH):
    os.mkdir(TODAYBACKUPPATH)

#备份数据库
    dumpcmd = "mysqldump -u " + DB_USER + " -p" + DB_USER_PASSWORD + DB_NAME + ">" + TODAYBACKUPPATH + "/" + "DB_NAME" + ".sql"
    os.system(dumpcmd)
    print "database is backuping..."
