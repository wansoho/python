#!/usr/bin/python
#coding:utf-8

import os


#def main():
    print 'hello world'
    print "这是黎明"
    print '这是张杰'

   
