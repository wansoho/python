#!/usr/bin/python
#coding:utf-8

for i in range(0,100):
#    print(i)
     print("Item {0},{1}".format(i,"hello"))
